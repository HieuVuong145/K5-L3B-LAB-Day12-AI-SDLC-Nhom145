"""Nạp và kiểm scenario (Contract D). Trả về dict của đúng khối theo mode.

KHUNG: kiểm cú pháp, id trùng, bộ đếm âm, khoang vượt sức chứa, trường lạ.
TODO(nhóm): bổ sung kiểm mâu thuẫn mức luật mà nhóm cần (khách giữ chỗ quá kho, đơn assigned
phải có đúng một món, khách eating thiếu giá/tip...) — xem PRD-0 mục D và 'Mâu thuẫn -> mã 2'.
"""

import json

from .errors import BadInput
from .inventory import KINDS_ALL, KINDS_P1, validate_individual_items, validate_items

GATHER_KEYS = {"player", "hold", "nodes", "fish", "random_fish", "time_left_ticks", "monsters", "ca_ho", "random_ho"}
GATHER_PLAYER_KEYS = {"pos", "vel", "heading_deg", "hp", "oxygen_ticks", "zero_oxy_ticks",
                      "invuln_ticks", "catch_cd_ticks", "attack_cd_ticks"}
NODE_KINDS = ("bong_dien_dien", "bong_sung")
FISH_KINDS = ("ca_linh", "ca_loc")
QUAN_PLAYER_KEYS = {"pos", "vel"}
QUAN_KEYS = {"player", "stock", "hand", "stoves", "tables", "customers", "random_customers",
             "reputation", "time_left_ticks"}


def _check_ids(name, arr):
    if not isinstance(arr, list):
        raise BadInput(f"{name} phải là mảng")
    seen = set()
    for e in arr:
        if not isinstance(e, dict) or not isinstance(e.get("id"), str) or not e["id"]:
            raise BadInput(f"{name}: mỗi phần tử cần id (chuỗi khác rỗng)")
        if e["id"] in seen:
            raise BadInput(f"{name}: id trùng {e['id']}")
        seen.add(e["id"])


DAY_KEYS = {"money", "earned", "reputation", "upgrades", "day_plan"}


def _validate_day(data, tuning):
    day = data.get("day", {})
    if not isinstance(day, dict) or set(day) - DAY_KEYS:
        raise BadInput("day chỉ nhận money, earned, reputation, upgrades, day_plan")
    money, earned = day.get("money", 0), day.get("earned", 0)
    for name, v in (("money", money), ("earned", earned)):
        if isinstance(v, bool) or not isinstance(v, int) or v < 0:
            raise BadInput(f"day.{name} phải là số nguyên >= 0")
    if money > earned:
        raise BadInput("day.money phải <= day.earned")
    rep = day.get("reputation", tuning["quan"]["reputation_initial"])
    if not isinstance(rep, (int, float)) or isinstance(rep, bool):
        raise BadInput("day.reputation phải là số")
    up = day.get("upgrades", {})
    if not isinstance(up, dict) or not all(isinstance(k, str) and isinstance(v, int) and not isinstance(v, bool) and v >= 0 for k, v in up.items()):
        raise BadInput("day.upgrades phải là map tên -> cấp >= 0")
    plan = day.get("day_plan")
    if plan is not None:
        if not isinstance(plan, list) or not plan:
            raise BadInput("day.day_plan phải là mảng")
        for item in plan:
            if not isinstance(item, dict) or "day" not in item or not isinstance(item.get("dishes"), dict) or not item["dishes"]:
                raise BadInput("day.day_plan: mỗi mục cần day và dishes")
    for blk in ("gather", "quan"):
        if blk in data and not isinstance(data[blk], dict):
            raise BadInput(f"khối {blk} phải là object")
    if "quan" in data and ("stock" in data["quan"] or "reputation" in data["quan"]):
        raise BadInput("chạy day không nhận quan.stock / quan.reputation")
    return data


def load_scenario(path, mode: str, tuning: dict) -> dict:
    if path is None:
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError) as e:
        raise BadInput(f"không đọc được scenario {path}: {e}")
    if not isinstance(data, dict) or not set(data) <= {"gather", "quan", "day"}:
        raise BadInput("scenario chỉ được có khối 'gather', 'quan' hoặc 'day'")
    if mode == "day":
        return _validate_day(data, tuning)
    if set(data) - {mode}:
        raise BadInput(f"khối sai mode: chạy --mode {mode} chỉ nhận khối '{mode}'")
    block = data.get(mode, {})
    if not isinstance(block, dict):
        raise BadInput(f"khối {mode} phải là object")
    allowed = GATHER_KEYS if mode == "gather" else QUAN_KEYS
    extra = set(block) - allowed
    if extra:
        raise BadInput(f"trường lạ/chưa hỗ trợ trong {mode}: {sorted(extra)}")
    dur = int(round(tuning[mode]["duration_s"] * 60))
    if "time_left_ticks" in block:
        t = block["time_left_ticks"]
        if isinstance(t, bool) or not isinstance(t, int) or not (1 <= t <= dur):
            raise BadInput(f"time_left_ticks phải là số nguyên trong [1, {dur}]")
    if mode == "gather":
        _validate_gather(block, tuning)
    else:
        _validate_quan(block, tuning)
    return block


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _nonneg_int(name, v):
    if isinstance(v, bool) or not isinstance(v, int) or v < 0:
        raise BadInput(f"{name} phải là số nguyên không âm")


def _pos(name, pos, bounds, axes=("x", "d")):
    if not (isinstance(pos, list) and len(pos) == 2 and all(_num(c) for c in pos)):
        raise BadInput(f"{name} phải là [{axes[0]}, {axes[1]}]")
    for c, axis in zip(pos, axes):
        lo, hi = bounds[axis]
        if not (lo <= c <= hi):
            raise BadInput(f"{name} nằm ngoài vùng nước ({axis} ∈ [{lo}, {hi}])")


def _validate_gather(b, tuning):
    g = tuning["gather"]
    bounds = g["bounds"]
    for arr in ("nodes", "fish"):
        if arr in b:
            _check_ids(arr, b[arr])
    if "random_fish" in b and not isinstance(b["random_fish"], bool):
        raise BadInput("random_fish phải là boolean")
    if "hold" in b:
        h = b["hold"]
        if not isinstance(h, list):
            raise BadInput("hold phải là mảng")
        if len(h) > g["hold_capacity"]:
            raise BadInput("hold vượt sức chứa")
        for item in h:
            if isinstance(item, str):
                if item not in KINDS_ALL:
                    raise BadInput(f"hold có nguyên liệu lạ: {item}")
            elif isinstance(item, dict):
                iid = item.get("id")
                if not isinstance(iid, str) or not iid:
                    raise BadInput(f"hold có id không hợp lệ: {iid!r}")
                kind = item.get("kind")
                if kind not in KINDS_ALL:
                    raise BadInput(f"hold có nguyên liệu lạ: {kind}")
                fresh = item.get("fresh")
                if isinstance(fresh, bool) or not isinstance(fresh, (int, float)) or not (0.0 <= fresh <= 100.0):
                    raise BadInput(f"hold có fresh không hợp lệ: {fresh!r}")
            else:
                raise BadInput("hold phải là mảng id nguyên liệu hợp lệ")
    p = b.get("player", {})
    if not isinstance(p, dict):
        raise BadInput("player phải là object")
    extra = set(p) - GATHER_PLAYER_KEYS
    if extra:
        raise BadInput(f"trường lạ/chưa hỗ trợ trong gather.player: {sorted(extra)}")
    if "pos" in p:
        _pos("player.pos", p["pos"], bounds)
    if "vel" in p and not (isinstance(p["vel"], list) and len(p["vel"]) == 2 and all(_num(c) for c in p["vel"])):
        raise BadInput("player.vel phải là [x, d]")
    if "heading_deg" in p and not _num(p["heading_deg"]):
        raise BadInput("player.heading_deg phải là số")
    for key in ("invuln_ticks", "catch_cd_ticks", "zero_oxy_ticks", "oxygen_ticks", "hp"):
        if key in p:
            _nonneg_int(f"player.{key}", p[key])
    omax = int(round(g["oxygen_max_s"] * 60))
    if "oxygen_ticks" in p and p["oxygen_ticks"] > omax:
        raise BadInput("player.oxygen_ticks vượt oxy tối đa")
    if "hp" in p and not (1 <= p["hp"] <= g["hp_max"]):
        raise BadInput("player.hp phải trong [1, hp_max]")
    if "zero_oxy_ticks" in p:
        pos = p.get("pos", g["start_pos"])
        oxy = p.get("oxygen_ticks", omax)
        if p["zero_oxy_ticks"] > 59:
            raise BadInput("player.zero_oxy_ticks phải trong [0, 59]")
        if p["zero_oxy_ticks"] > 0 and not (oxy == 0 and pos[1] > g["surface_depth"]):
            raise BadInput("player.zero_oxy_ticks > 0 chỉ khi oxy = 0 và đang dưới nước")
    for n in b.get("nodes", []):
        if n.get("kind") not in NODE_KINDS:
            raise BadInput(f"nodes.{n['id']}: kind phải là một trong {NODE_KINDS}")
        _pos(f"nodes.{n['id']}.pos", n.get("pos"), bounds)
        if n["pos"][1] != 0:
            raise BadInput(f"nodes.{n['id']}: nút hái nằm ở mặt nước (d = 0)")
        if "regrow_ticks" in n:
            _nonneg_int(f"nodes.{n['id']}.regrow_ticks", n["regrow_ticks"])
    for f in b.get("fish", []):
        if f.get("kind") not in FISH_KINDS:
            raise BadInput(f"fish.{f['id']}: kind phải là một trong {FISH_KINDS}")
        _pos(f"fish.{f['id']}.pos", f.get("pos"), bounds)
        if f["pos"][1] <= g["surface_depth"]:
            raise BadInput(f"fish.{f['id']}: đàn cá phải ở dưới nước")
        if "heading_deg" in f and not _num(f["heading_deg"]):
            raise BadInput(f"fish.{f['id']}.heading_deg phải là số")


def _validate_quan(b, tuning):
    for arr in ("stoves", "tables", "customers"):
        if arr in b:
            _check_ids(arr, b[arr])
    stock_items_by_id = {}
    if "stock" in b:
        st = b["stock"]
        if isinstance(st, list):
            validated_st = validate_individual_items(st, KINDS_ALL)
            for it in validated_st:
                stock_items_by_id[it["id"]] = it
        elif isinstance(st, dict):
            validate_items(st, KINDS_ALL)
        else:
            raise BadInput("quan.stock phải là mảng cá thể hoặc object")
    p = b.get("player", {})
    if not isinstance(p, dict) or set(p) - QUAN_PLAYER_KEYS:
        raise BadInput("quan.player chỉ có pos và vel")
    qb = tuning["quan"]["bounds"]
    if "pos" in p:
        _pos("player.pos", p["pos"], qb, axes=("x", "z"))
    if "vel" in p and not (isinstance(p["vel"], list) and len(p["vel"]) == 2 and all(_num(c) for c in p["vel"])):
        raise BadInput("player.vel phải là [x, z]")
    table_ids = [c.get("table_id") for c in b.get("customers", [])]
    known = {t["id"] for t in tuning["quan"]["tables"]} | {t.get("id") for t in b.get("tables", [])}
    reserved_seen = set()
    for c in b.get("customers", []):
        if not isinstance(c.get("table_id"), str) or c["table_id"] not in known:
            raise BadInput(f"customers.{c['id']}: table_id phải là bàn có thật")
        dish_id = c.get("dish_id")
        recipe = tuning["menu"].get(dish_id, {}).get("recipe", {}) if dish_id else {}
        res = c.get("reserved")
        if res is not None:
            if isinstance(res, list):
                res_kinds = {}
                for iid in res:
                    if not isinstance(iid, str) or not iid:
                        raise BadInput(f"id trong reserved không hợp lệ: {iid!r}")
                    if iid in reserved_seen:
                        raise BadInput(f"cá thể {iid} được giữ bởi hơn một đơn")
                    reserved_seen.add(iid)
                    if stock_items_by_id:
                        if iid not in stock_items_by_id:
                            raise BadInput(f"cá thể {iid} trong reserved không có trong stock")
                        it = stock_items_by_id[iid]
                        if it["fresh"] < 30:
                            raise BadInput(f"cá thể {iid} trong reserved đã ươn (fresh < 30)")
                        res_kinds[it["kind"]] = res_kinds.get(it["kind"], 0) + 1
                if recipe and stock_items_by_id and res_kinds != recipe:
                    raise BadInput(f"reserved không khớp công thức của món {dish_id}")
            elif isinstance(res, dict):
                validate_items(res, KINDS_ALL)
            else:
                raise BadInput("reserved phải là mảng id hoặc object")
    if len(table_ids) != len(set(table_ids)):
        raise BadInput("hai khách cùng bàn")
